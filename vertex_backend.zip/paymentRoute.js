const express = require("express");
const {
  createOrder,
  getLogo,
  paymentCallback,
  getPayment,
} = require("./paymentControler");
const router = express.Router();

router.get("/createorder/:id", createOrder);
router.post("/payment/callback", paymentCallback);
router.get("/payments/:paymentId", getPayment);
router.get("/logo", getLogo);
module.exports = router;
